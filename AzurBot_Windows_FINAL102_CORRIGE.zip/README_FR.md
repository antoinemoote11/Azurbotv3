# Azur Bot Windows FINAL9

Améliorations :
- Curseur de seuil PV fluide de 25 à 100 %, réglable par pas de 1 %. Repères visuels tous les 25 %.
- Le bot privilégie la lecture OCR des PV actuels / PV maximum affichés à droite de la barre.
- Si les chiffres ne sont pas lisibles, il mesure la barre verte dans la zone proche du libellé PV. Si la lecture est incertaine, il ne clique pas sur « Rentrer au village ».
- Conservation des actions existantes : niveau du héros (Force puis Confirmer), météo, niveau du compagnon, continuer, repartir et partir.

Le projet est destiné à être placé dans le dépôt GitHub utilisé par le workflow de compilation Windows.

## FINAL102 – lecture des PV renforcée
- Un seul OCR par capture (plus rapide), lecture « PV actuels / max » plus tolérante (O→0, I/l→1, séparateurs de milliers, « PU/PY » pour « PV »).
- Si le texte est trop petit : relecture sur un crop agrandi x3 (normal puis inversé).
- Barre verte : calcul du vrai ratio rempli/total (l'ancienne version divisait par 48 % de la largeur de l'écran), uniquement si le bord droit de la barre est détecté.
- Dernière valeur PV lue pendant le combat mémorisée 12 s (la fenêtre de victoire cache souvent la barre).
- Retour au village seulement après 2 lectures basses consécutives.
- PV illisibles : aucun clic, et une capture + le texte OCR sont enregistrés dans Bureau\AzurBot_debug.
